﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jugador : MonoBehaviour
{
    [SerializeField]
    private Rigidbody playerBody;

    // Start is called before the first frame update
    void Start()
    {
        playerBody = GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            playerBody.AddForce(0, 11f, 0);
        }
        Vector3 inputVector = new Vector3(Input.GetAxisRaw("Horizontal") * 3f, playerBody.velocity.y, Input.GetAxisRaw("Vertical") * 3f);

        playerBody.velocity = inputVector;


    }
}
    