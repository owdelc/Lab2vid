﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class activ : MonoBehaviour
{
    [SerializeField] private Transform Player;
    [SerializeField] private Transform respawn;

    private void OnTriggerEnter(Collider other)
    {
        Vector3 position = respawn.transform.position;
        Player.transform.position = position;
    }
}
